import React, { useState } from "react";

import { canDownloadChartImage } from "../chart-image.js";
import { validComponentId } from "../chart-permalink.js";
import { useOptionalDataAppShell } from "../DataAppContext.jsx";
import { reviewedNarrativeQueries } from "../source-provenance.js";
import { Icon } from "./Icon.jsx";
import { Filters } from "./Controls.jsx";
import { RichNarrative } from "./RichMarkdown.jsx";
import { useSectionFilterPlacement } from "./Section.jsx";
import { SmoothCardSurface } from "./SmoothCardSurface.jsx";
import { InfoTooltip, Menu, MenuItem } from "./ui.jsx";

function requireStableComponentId(id) {
  if (typeof id !== "string" || !id.trim()) {
    throw new Error("DataComponent requires a non-empty stable id.");
  }
  return id;
}

function Info({ description }) {
  return <InfoTooltip>{description}</InfoTooltip>;
}

function ChartImageActions({ component, onCopy }) {
  if (!canDownloadChartImage(component.id)) return null;
  return <>
    <MenuItem icon="download" onSelect={() => onCopy("download-image", component)}>Download PNG</MenuItem>
    <MenuItem icon="copy" onSelect={() => onCopy("image", component)}>Copy as image</MenuItem>
  </>;
}

export function ComponentActions({
  component,
  editMode,
  canEdit = true,
  published = false,
  onOpen,
  onHide,
  onEdit,
  onCopy,
  additionalActions,
  required = false,
}) {
  return (
    <Menu label={`${component.title} actions`} trigger={
      <button type="button" className="menu-trigger" aria-label={`${component.title} actions`}><Icon name="more" /></button>
    }>
      {canEdit && component.chart
        && <MenuItem icon="edit" onSelect={() => onOpen("explore", component)}>Edit chart</MenuItem>}
      <MenuItem icon="database" onSelect={() => onOpen("source", component)}>View data source</MenuItem>
      {onCopy && component.chart && <ChartImageActions component={component} onCopy={onCopy} />}
      {onCopy && <MenuItem icon="copy" onSelect={() => onCopy("data", component)}>Copy data</MenuItem>}
      {published && onCopy && validComponentId(component.id) && <MenuItem icon="link"
        onSelect={() => onCopy(component.chart ? "link" : "component-link", component)}>Copy link</MenuItem>}
      {additionalActions}
      {canEdit && onEdit && <MenuItem icon="edit" onSelect={onEdit}>Edit text</MenuItem>}
      {canEdit && editMode && !required
        && <MenuItem icon="trash" danger onSelect={() => onHide(component.id)}>Hide</MenuItem>}
    </Menu>
  );
}

export function DataComponent({
  id, title, queryId, queryIds, kind, chart, displayRows, sourceRows, sourceRowsByQuery,
  description, editMode, canEdit, className = "",
  published, onOpen, onHide, onEdit, onCopy, onRegisterComponent, onTitleChange, titleOverrides, additionalActions,
  hideDescriptionTooltip = false, variant = "plain", padding = "standard", smoothCorners,
  scopeFilters = [], sectionFilters, showHeading = true, showActions = true, headingLevel = 2, children,
}) {
  const shell = useOptionalDataAppShell();
  const sharedActions = shell?.componentActions ?? {};
  editMode ??= sharedActions.editMode ?? false;
  canEdit ??= sharedActions.canEdit ?? true;
  published ??= sharedActions.published ?? false;
  onOpen ??= sharedActions.onOpen;
  onHide ??= sharedActions.onHide;
  onCopy ??= sharedActions.onCopy;
  onRegisterComponent ??= sharedActions.onRegisterComponent;
  onTitleChange ??= sharedActions.onTitleChange;
  titleOverrides ??= sharedActions.titleOverrides;
  const componentId = requireStableComponentId(id);
  if (typeof queryId !== "string" || !queryId.trim()) {
    throw new Error(`DataComponent "${componentId}" requires a stable reviewed query id.`);
  }
  const reviewedQueryIds = reviewedNarrativeQueries({
    id: componentId, queryId, queryIds, kind, chart, sourceRowsByQuery,
  }, shell?.queries);
  const [editedTitle, setEditedTitle] = useState(title);
  const displayedTitle = titleOverrides?.[id] ?? (onTitleChange ? title : editedTitle);
  const editableTitle = editMode && canEdit;
  // Keep existing custom report blocks compatible. New narrative sections own
  // their Markdown and opt into a separate heading explicitly.
  const reportNarrative = shell?.snapshot.surface === "report" && kind === "custom";
  const component = { id: componentId, title: displayedTitle, queryId, kind, chart, displayRows, sourceRows, description, scopeFilters,
    ...(reviewedQueryIds.length > 1 ? { queryIds: reviewedQueryIds } : {}),
    ...(sourceRowsByQuery ? { sourceRowsByQuery } : {}),
  };
  const Heading = `h${Math.max(2, Math.min(6, Number(headingLevel) || 2))}`;
  const card = variant === "card";
  const filterPlacement = useSectionFilterPlacement(sectionFilters?.sectionScope, componentId);
  let mergedNarrative = false;
  const content = reportNarrative && showHeading ? React.Children.map(children, (child) => {
    if (mergedNarrative || !React.isValidElement(child) || child.type !== RichNarrative
      || typeof child.props.id !== "string" || typeof child.props.value !== "string") return child;
    mergedNarrative = true;
    const authored = typeof child.props.value === "string" ? child.props.value.replace(/\\r\\n|\\n/g, "\n") : "";
    const markdown = /^\s*#{1,4}\s+/u.test(authored)
      ? authored
      : `## ${displayedTitle}\n\n${authored.trim()}`;
    return React.cloneElement(child, { value: markdown });
  }) : children;
  const renderHeading = showHeading && !mergedNarrative;
  const narrativeActions = !renderHeading && (reportNarrative || kind === "narrative");
  function commitTitle(event) {
    const next = event.currentTarget.textContent.trim();
    if (!next) {
      event.currentTarget.textContent = displayedTitle;
      return;
    }
    if (onTitleChange) onTitleChange(next, id);
    else setEditedTitle(next);
  }
  return (
    <section className={["dashboard-component", className, editMode && "is-editing"].filter(Boolean).join(" ")}
      ref={onRegisterComponent ? (element) => onRegisterComponent(component, element) : undefined}
      tabIndex={-1}
      data-component-variant={variant} data-card-padding={card ? padding : undefined}
      data-component-id={componentId} data-component-kind={kind} data-query-id={queryId}
      data-query-ids={reviewedQueryIds.length > 1 ? reviewedQueryIds.join(" ") : undefined}>
      {(smoothCorners ?? card) && <SmoothCardSurface />}
      {(showActions || renderHeading) && <header className={["component-header", narrativeActions && "report-narrative-actions"].filter(Boolean).join(" ")}>
        {renderHeading && <Heading className="component-title">
          <span className="component-title-text" contentEditable={editableTitle}
            suppressContentEditableWarning aria-label={editableTitle ? `Edit ${displayedTitle} title` : undefined}
            onBlur={editableTitle ? commitTitle : undefined}
            onKeyDown={editableTitle ? (event) => {
              if (event.key === "Enter") { event.preventDefault(); event.currentTarget.blur(); }
              if (event.key === "Escape") {
                event.currentTarget.textContent = displayedTitle;
                event.currentTarget.blur();
              }
            } : undefined}>{displayedTitle}</span>
          {!hideDescriptionTooltip && description && description.trim().toLowerCase() !== displayedTitle.trim().toLowerCase()
            && <Info description={description} />}
        </Heading>}
        {showActions && <ComponentActions component={component} editMode={editMode} canEdit={canEdit} published={published}
          onOpen={onOpen} onHide={onHide} onEdit={onEdit} onCopy={onCopy} additionalActions={additionalActions} />}
      </header>}
      {sectionFilters && filterPlacement.component && <div className="component-section-filters" data-block-no-drag>
        <span className="component-section-filter-label">{sectionFilters.ariaLabel}</span>
        <Filters {...sectionFilters} sectionScope={undefined} ariaLabel={`${displayedTitle} filters`} />
      </div>}
      {content}
    </section>
  );
}

// Optional source-aware wrapper; authored children determine the document structure.
export function ReportSection({ className = "", ...props }) {
  return <DataComponent {...props} kind="narrative" hideDescriptionTooltip
    className={["report-narrative-section", className].filter(Boolean).join(" ")} />;
}
