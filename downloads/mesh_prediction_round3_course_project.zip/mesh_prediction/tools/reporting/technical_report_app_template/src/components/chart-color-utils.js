export function hexToHsv(hex) {
  const [r, g, b] = [1, 3, 5].map((offset) => parseInt(hex.slice(offset, offset + 2), 16) / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
  const hue = !delta ? 0 : max === r ? ((g - b) / delta) % 6
    : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4;
  return { hue: (hue * 60 + 360) % 360, saturation: max ? delta / max * 100 : 0, value: max * 100 };
}

export function hsvToHex({ hue, saturation, value }) {
  const v = value / 100, c = v * saturation / 100;
  const h = ((hue % 360) + 360) % 360 / 60;
  const x = c * (1 - Math.abs(h % 2 - 1)), m = v - c;
  const rgb = h < 1 ? [c, x, 0] : h < 2 ? [x, c, 0] : h < 3 ? [0, c, x]
    : h < 4 ? [0, x, c] : h < 5 ? [x, 0, c] : [c, 0, x];
  return `#${rgb.map((channel) => Math.round((channel + m) * 255).toString(16).padStart(2, "0")).join("")}`;
}

export function colorNameFromHex(hex) {
  if (!/^#[\da-f]{6}$/iu.test(hex ?? "")) return "Theme color";
  const { hue, saturation, value } = hexToHsv(hex);
  if (value <= 12) return "Black";
  if (saturation < 12) return value >= 96 ? "White" : "Gray";
  if (hue < 15 || hue >= 345) return "Red";
  if (hue < 42) return "Orange";
  if (hue < 68) return "Yellow";
  if (hue < 100) return "Lime";
  if (hue < 165) return "Green";
  if (hue < 180) return "Teal";
  if (hue < 205) return "Cyan";
  if (hue < 250) return "Blue";
  if (hue < 290) return "Purple";
  if (hue < 325) return "Magenta";
  return "Pink";
}

export function resolvedColorHex(color, parent) {
  if (/^#[\da-f]{6}$/iu.test(color ?? "")) return color;
  const probe = document.createElement("span");
  probe.style.color = color || "var(--chart-1)";
  parent.append(probe);
  const resolved = getComputedStyle(probe).color;
  probe.remove();
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 1;
  const context = canvas.getContext("2d");
  context.fillStyle = resolved;
  context.fillRect(0, 0, 1, 1);
  return `#${[...context.getImageData(0, 0, 1, 1).data].slice(0, 3)
    .map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
}

export function resolvedColorName(color, parent) {
  return colorNameFromHex(resolvedColorHex(color, parent));
}
