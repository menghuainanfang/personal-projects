# 物理教师监督训练

本轮入口：[中文研究报告](runs/physical_teacher_01/中文研究报告.md)。

1200组训练、400组验证、400组测试均已生成非线性物理能量教师标签。
3个新MLP模型已训练完成，权重、教师节点、训练损失与测试结果全部保存。
400测试例的直接预测按三个随机种子评估；另有20例、四初值、各2次同目标精修。

在本文件所在目录运行：

    python runs/physical_teacher_01/study.py
    python runs/physical_teacher_01/report.py

依赖numpy、scipy、matplotlib、torch。已有教师和权重会被复用。
study.py复用runs/physical_X_01内的训练、物理能量和合法性实现，以及src内的原始网络和评价函数。
完整包内同时保留这些依赖、旧三种子对照权重及旧教师数据，可独立解压复现。
表格、公式、限制和计时口径见中文研究报告。
