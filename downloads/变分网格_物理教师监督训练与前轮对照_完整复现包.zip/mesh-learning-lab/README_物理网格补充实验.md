# 直接物理网格补充实验

[中文结果分析](runs/physical_X_01/中文结果分析.md)包含全部结论、公式和图表。

本包保存1200训练/400验证/400测试的真实教师数据，3个直接X模型、3个对应Q模型，
400测试例的全部预测节点、20例四类物理精修的终点与逐步记录，以及可运行代码。
旧课程设计、原2015年复现和独立研究的既有结果均保留不变。

在本文件所在目录，使用已安装numpy、scipy、matplotlib、torch的Python执行：

    python runs/physical_X_01/run.py
    python runs/physical_X_01/analyze.py

第一个命令复用现有模型权重并重新评估；第二个命令从保存的数值表生成图像与报告。
完整重训X时，将runs/physical_X_01/models保存在其他位置后再运行。
Q权重及训练信息位于runs/scale_study_01/models；Q训练程序为src/train_fixed_q.py。
训练和评估均采用CPU单线程，计时随机器与负载变化。

数据表：

- prediction_per_case.csv：2400条直接预测记录（400例×2种表示×3种子）。
- summary_prediction.csv：三种子汇总，节点误差、几何质量、函数插值误差及在线耗时。
- physical_per_case.csv：160条相同物理能量精修记录（20例×4初值×2次重复）。
- physical_paired.csv：相同终点条件下的配对比较。
- summary_physical.csv：物理精修汇总。

以上数据表和图像均位于runs/physical_X_01。
本包内的X标签仍来自冻结Q教师的重建，不是重新生成的物理能量极小点标签。
