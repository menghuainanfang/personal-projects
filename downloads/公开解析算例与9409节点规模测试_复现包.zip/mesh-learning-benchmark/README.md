# 公开解析算例与网格规模测试

进入解压目录，先阅读runs/benchmark_scale_05/中文测试报告.md。
冻结模型来自此前四类场训练，未为本轮重新训练。

需要numpy、scipy、matplotlib、torch。已有结果与图片可直接阅读。
重新计算：

    python runs/benchmark_scale_05/benchmark.py
    python runs/benchmark_scale_05/report.py

benchmark.py包含解析场定义、完整计时口径与PDE求积阶数。
report.py从真实CSV生成表格与图片。finalize.py用于对已有结果作独立高阶求积评价和串行计时。
sources中的MMPDElab官方MATLAB源码按其AGPL-3.0许可保留；其余文件沿用原项目许可。
这是相同解析函数的本地实现与规模压力测试，不是MMPDElab或UM2N官方完整基准复现。
